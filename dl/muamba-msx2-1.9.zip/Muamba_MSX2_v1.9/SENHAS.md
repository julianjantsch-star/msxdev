# MUAMBA! v1.9 – senhas / passwords

As senhas valem nos dois idiomas. Digite no título em **ENTRAR COM A SENHA** (ou no jogo: ESC → SENHA → DIGITAR SENHA DE OUTRA PARTE).
Passwords work in both languages: title screen → **ENTER PASSWORD**.

| # | Senha | Onde começa | Itens na sacola |
|---|---|---|---|
| 1 | `6FNM ZHD7` | Pensão – recepção | canivete |
| 2 | `ALC8 XVPJ` | Avenida (rua) | canivete, guarda-chuva, cruzeiros |
| 3 | `TLJ8 XVPJ` | Avenida (rua) | canivete, batata, tereré, guarda-chuva, cruzeiros |
| 4 | `ER3A R7ZY` | Sindicato dos Muambeiros | canivete, batata, guarda-chuva, senha 7, cruzeiros |
| 5 | `2WWY BJ2G` | Churrascaria | canivete, batata, guarda-chuva, senha 7, cruzeiros |
| 6 | `NXEH 5XBW` | Avenida (rua) | canivete, batata, guarda-chuva, senha 7, cruzeiros |
| 7 | `A282 79L6` | Avenida (rua) | canivete, batata, guarda-chuva, senha 7, cruzeiros |
| 8 | `N90P ZLXM` | Avenida (rua) | canivete, batata, TV 21, guarda-chuva, senha 7 |
| 9 | `FAK8 LY72` | Avenida (rua) | canivete, batata, TV 21, bilhete do 43, guarda-chuva, senha 7 |
| 10 | `3FCD BFHF` | Ateliê da escola de samba | canivete, batata, TV 21, bilhete do 43, guarda-chuva, senha 7, fantasia suja |
| 11 | `UKXX HNJW` | Barracão da escola de samba | canivete, batata, TV 21, bilhete do 43, guarda-chuva, senha 7, fantasia limpa |
| 12 | `BR7G 70U9` | Ateliê da escola de samba | canivete, batata, fantasia de baiana, TV 21, bilhete do 43, guarda-chuva, senha 7 |
| 13 | `YU05 WC5N` | Barracão da escola de samba | canivete, batata, fantasia de baiana, bilhete do 43, guarda-chuva, senha 7, carrinho com a TV |
| 14 | `KYJN KRE3` | Cabeceira da ponte | canivete, batata, fantasia de baiana, bilhete do 43, guarda-chuva, senha 7, carrinho com a TV |
| 15 | `74CU S3RG` | Avenida (rua) | canivete, batata, fantasia de baiana, bilhete do 43, guarda-chuva, senha 7, carrinho com a TV |
| 16 | `74LU S3RG` | Avenida (rua) | canivete, batata, tereré, fantasia de baiana, bilhete do 43, guarda-chuva, senha 7, carrinho com a TV |
| 17 | `B95C NE0W` | Ponto do ônibus 43 | canivete, batata, fantasia de baiana, bilhete do 43, guarda-chuva, Hot Bit, senha 7, carrinho com a TV |
| 18 | `GDPX LS3A` | Churrascaria | canivete, batata, fantasia de baiana, bilhete do 43, guarda-chuva, carteirinha, senha 7, carrinho com a TV |
| 19 | `4EGK A5CP` | Ponte da Amizade (lado paraguaio) – início do Ato II | canivete, batata, fantasia de baiana, bilhete do 43, guarda-chuva, carteirinha, senha 7, carrinho com a TV |
| 20 | `RK24 HGM4` | Rua da galeria (Ciudad del Este) | canivete, batata, fantasia de baiana, bilhete do 43, guarda-chuva, carteirinha, senha 7, carrinho com a TV |
| 21 | `RKT4 HGM4` | Rua da galeria (Ciudad del Este) | canivete, batata, tereré, fantasia de baiana, bilhete do 43, guarda-chuva, carteirinha, senha 7, carrinho com a TV |
| 22 | `CR3P 7UYH` | Rua da galeria (Ciudad del Este) | canivete, batata, tereré, fantasia de baiana, bilhete do 43, guarda-chuva, carteirinha, senha 7, crachá, carrinho com a TV |
| 23 | `ZVDV W68X` | Rua da galeria (Ciudad del Este) | canivete, batata, tereré, fantasia de baiana, bilhete do 43, guarda-chuva, carteirinha, senha 7, crachá, carrinho com a TV |
| 24 | `ZVDZ W68X` | Rua da galeria (Ciudad del Este) | canivete, batata, tereré, fantasia de baiana, bilhete do 43, guarda-chuva, carteirinha, senha 7, crachá, cotação, carrinho com a TV |
| 25 | `ZVHV W68X` | Rua da galeria (Ciudad del Este) | canivete, batata, nota fiscal, tereré, fantasia de baiana, bilhete do 43, guarda-chuva, carteirinha, senha 7, crachá, carrinho com a TV |
| 26 | `L02A JJAB` | Elevador da galeria | canivete, batata, nota fiscal, fantasia de baiana, bilhete do 43, guarda-chuva, carteirinha, senha 7, crachá, carrinho com a TV |
| 27 | `82ZY RWKR` | Elevador da galeria | canivete, batata, fantasia de baiana, bilhete do 43, guarda-chuva, carteirinha, senha 7, crachá, carrinho com a TV |
| 28 | `G6PM E845` | Arquivo morto (Ato III) | canivete, fantasia de baiana, bilhete do 43, guarda-chuva, carteirinha, crachá, carimbo, carrinho com a TV |
| 29 | `Z6PM E945` | Arquivo morto (Ato III) | canivete, fantasia de baiana, bilhete do 43, guarda-chuva, carteirinha, crachá, carimbo, processo 1972/43, carrinho com a TV |
| 30 | `MBD8 5JXJ` | Salão dos guichês (Ato III) | canivete, fantasia de baiana, bilhete do 43, guarda-chuva, carteirinha, crachá, carimbo, processo 1972/43, carrinho com a TV |
| 31 | `9G2P UXPY` | Sala do Dr. Lechuga (Ato III) | canivete, fantasia de baiana, bilhete do 43, guarda-chuva, carteirinha, crachá, carimbo, processo 1972/43, carrinho com a TV |
