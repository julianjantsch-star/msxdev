# MUAMBA! v1.6 – senhas / passwords

As senhas valem nos dois idiomas. Digite no título em **ENTRAR COM A SENHA** (ou no jogo: ESC → SENHA → DIGITAR SENHA DE OUTRA PARTE).
Passwords work in both languages: title screen → **ENTER PASSWORD**.

| # | Senha | Onde começa | Itens na sacola |
|---|---|---|---|
| 1 | `6FNM ZHD7` | Pensão – recepção | canivete |
| 2 | `ALC8 XVPJ` | Avenida (rua) | canivete, guarda-chuva, cruzeiros |
| 3 | `TLJ8 XVPJ` | Avenida (rua) | canivete, batata, tereré, guarda-chuva, cruzeiros |
| 4 | `ER3A R7ZY` | Sindicato dos Muambeiros | canivete, batata, guarda-chuva, senha 7, cruzeiros |
| 5 | `2WWY BJ2G` | Churrascaria | canivete, batata, guarda-chuva, senha 7, cruzeiros |
| 6 | `EZEH 5XBU` | Avenida (rua) | canivete, batata, TV 21, guarda-chuva, senha 7 |
| 7 | `6482 99L8` | Avenida (rua) | canivete, batata, TV 21, bilhete do 43, guarda-chuva, senha 7 |
| 8 | `T90P XRXM` | Ateliê da escola de samba | canivete, batata, TV 21, bilhete do 43, guarda-chuva, senha 7, fantasia suja |
| 9 | `KAK8 LY73` | Barracão da escola de samba | canivete, batata, TV 21, bilhete do 43, guarda-chuva, senha 7, fantasia limpa |
| 10 | `3FVD BBHF` | Ateliê da escola de samba | canivete, batata, fantasia de baiana, TV 21, bilhete do 43, guarda-chuva, senha 7 |
| 11 | `PMEX GNJV` | Barracão da escola de samba | canivete, batata, fantasia de baiana, bilhete do 43, guarda-chuva, senha 7, carrinho com a TV |
| 12 | `BN7G 60U9` | Avenida (rua) | canivete, batata, fantasia de baiana, bilhete do 43, guarda-chuva, senha 7, carrinho com a TV |
| 13 | `BNYG 60U9` | Avenida (rua) | canivete, batata, tereré, fantasia de baiana, bilhete do 43, guarda-chuva, senha 7, carrinho com a TV |
| 14 | `FU05 5C5N` | Ponto do ônibus 43 | canivete, batata, fantasia de baiana, bilhete do 43, guarda-chuva, Hot Bit, senha 7, carrinho com a TV |
| 15 | `KYJN 3RE3` | Churrascaria | canivete, batata, fantasia de baiana, bilhete do 43, guarda-chuva, carteirinha, senha 7, carrinho com a TV |
| 16 | `74CU 93RG` | Ponte da Amizade (lado paraguaio) – início do Ato II | canivete, batata, fantasia de baiana, bilhete do 43, guarda-chuva, carteirinha, senha 7, carrinho com a TV |
| 17 | `U95C XE0W` | Rua da galeria (Ciudad del Este) | canivete, batata, fantasia de baiana, bilhete do 43, guarda-chuva, carteirinha, senha 7, carrinho com a TV |
| 18 | `U9WC XE0W` | Rua da galeria (Ciudad del Este) | canivete, batata, tereré, fantasia de baiana, bilhete do 43, guarda-chuva, carteirinha, senha 7, carrinho com a TV |
| 19 | `GDFZ LS3A` | Rua da galeria (Ciudad del Este) | canivete, batata, tereré, fantasia de baiana, bilhete do 43, guarda-chuva, carteirinha, senha 7, crachá, carrinho com a TV |
| 20 | `4ERM A5CP` | Rua da galeria (Ciudad del Este) | canivete, batata, tereré, fantasia de baiana, bilhete do 43, guarda-chuva, carteirinha, senha 7, crachá, carrinho com a TV |
| 21 | `4ERS A5CP` | Rua da galeria (Ciudad del Este) | canivete, batata, tereré, fantasia de baiana, bilhete do 43, guarda-chuva, carteirinha, senha 7, crachá, cotação, carrinho com a TV |
| 22 | `4ELM A5CP` | Rua da galeria (Ciudad del Este) | canivete, batata, nota fiscal, tereré, fantasia de baiana, bilhete do 43, guarda-chuva, carteirinha, senha 7, crachá, carrinho com a TV |
| 23 | `RK62 HGM4` | Elevador da galeria | canivete, batata, nota fiscal, fantasia de baiana, bilhete do 43, guarda-chuva, carteirinha, senha 7, crachá, carrinho com a TV |
| 24 | `CRUP 7UYH` | Elevador da galeria | canivete, batata, fantasia de baiana, bilhete do 43, guarda-chuva, carteirinha, senha 7, crachá, carrinho com a TV |
| 25 | `LVKW W6ZX` | Arquivo morto (Ato III) | canivete, fantasia de baiana, bilhete do 43, guarda-chuva, carteirinha, crachá, carimbo, carrinho com a TV |
| 26 | `4VKW W7ZX` | Arquivo morto (Ato III) | canivete, fantasia de baiana, bilhete do 43, guarda-chuva, carteirinha, crachá, carimbo, processo 1972/43, carrinho com a TV |
| 27 | `R08B JKJB` | Salão dos guichês (Ato III) | canivete, fantasia de baiana, bilhete do 43, guarda-chuva, carteirinha, crachá, carimbo, processo 1972/43, carrinho com a TV |
| 28 | `C2XX RVBR` | Sala do Dr. Lechuga (Ato III) | canivete, fantasia de baiana, bilhete do 43, guarda-chuva, carteirinha, crachá, carimbo, processo 1972/43, carrinho com a TV |
