# MUAMBA! v2.0 – senhas / passwords

As senhas valem nos dois idiomas. Digite no título em **ENTRAR COM A SENHA** (ou no jogo: ESC → SENHA → DIGITAR SENHA DE OUTRA PARTE).
Passwords work in both languages: title screen → **ENTER PASSWORD**.

| # | Senha | Onde começa | Itens na sacola |
|---|---|---|---|
| 1 | `6FNM ZHD7` | Pensão – recepção | canivete |
| 2 | `2LC8 XVSL` | Avenida (rua) | canivete, guarda-chuva, cruzeiros |
| 3 | `6RUB R7X0` | Avenida (rua) | canivete, batata, tereré, guarda-chuva, cruzeiros |
| 4 | `TWWY BJ4E` | Sindicato dos Muambeiros | canivete, batata, guarda-chuva, senha 7, cruzeiros |
| 5 | `EXEH 5XDU` | Churrascaria | canivete, batata, guarda-chuva, senha 7, cruzeiros |
| 6 | `2282 79J8` | Avenida (rua) | canivete, batata, guarda-chuva, senha 7, cruzeiros |
| 7 | `N70P ZLZM` | Avenida (rua) | canivete, batata, guarda-chuva, senha 7, cruzeiros |
| 8 | `KAK8 JY74` | Avenida (rua) | canivete, batata, TV 21, guarda-chuva, senha 7, remarcadora |
| 9 | `BFCD BBHH` | Avenida (rua) | canivete, batata, TV 21, bilhete do 43, guarda-chuva, senha 7, remarcadora |
| 10 | `YKXX HJJT` | Ateliê da escola de samba | canivete, batata, TV 21, bilhete do 43, guarda-chuva, senha 7, fantasia suja, remarcadora |
| 11 | `PRPG 70U6` | Barracão da escola de samba | canivete, batata, TV 21, bilhete do 43, guarda-chuva, senha 7, fantasia limpa, remarcadora |
| 12 | `7W05 VC5R` | Ateliê da escola de samba | canivete, batata, fantasia de baiana, TV 21, bilhete do 43, guarda-chuva, senha 7, remarcadora |
| 13 | `UYJN KRE5` | Barracão da escola de samba | canivete, batata, fantasia de baiana, bilhete do 43, guarda-chuva, senha 7, carrinho de bebê, remarcadora |
| 14 | `F4CU S3RE` | Cabeceira da ponte | canivete, batata, fantasia de baiana, bilhete do 43, guarda-chuva, senha 7, carrinho de bebê, remarcadora |
| 15 | `395C EE0U` | Avenida (rua) | canivete, batata, fantasia de baiana, bilhete do 43, guarda-chuva, senha 7, carrinho de bebê, remarcadora |
| 15 | `39WC EE0U` | Avenida (rua) | canivete, batata, fantasia de baiana, bilhete do 43, guarda-chuva, senha 7, carrinho de bebê, remarcadora |
| 16 | `8DPX VS3C` | Ponto do ônibus 43 | canivete, batata, fantasia de baiana, bilhete do 43, guarda-chuva, Hot Bit, senha 7, carrinho de bebê, remarcadora |
| 17 | `CEGK A5CS` | Churrascaria | canivete, batata, fantasia de baiana, bilhete do 43, guarda-chuva, carteirinha, senha 7, carrinho de bebê, remarcadora |
| 18 | `ZK24 HGM2` | Ponte da Amizade (lado paraguaio) – início do Ato II | canivete, batata, fantasia de baiana, bilhete do 43, guarda-chuva, carteirinha, senha 7, carrinho de bebê, remarcadora |
| 19 | `LRUS 7UYF` | Rua da galeria (Ciudad del Este) | canivete, batata, fantasia de baiana, bilhete do 43, guarda-chuva, carteirinha, senha 7, carrinho de bebê, remarcadora |
| 19 | `LR3S 7UYF` | Rua da galeria (Ciudad del Este) | canivete, batata, fantasia de baiana, bilhete do 43, guarda-chuva, carteirinha, senha 7, carrinho de bebê, remarcadora |
| 20 | `8VDV W68Z` | Rua da galeria (Ciudad del Este) | canivete, batata, tereré, fantasia de baiana, bilhete do 43, guarda-chuva, carteirinha, senha 7, crachá, carrinho de bebê, remarcadora |
| 21 | `V0XA JJAD` | Rua da galeria (Ciudad del Este) | canivete, batata, tereré, fantasia de baiana, bilhete do 43, guarda-chuva, carteirinha, senha 7, crachá, carrinho de bebê, remarcadora |
| 22 | `G28Y RWKN` | Galeria Página 3 – térreo | canivete, batata, tereré, fantasia de baiana, bilhete do 43, guarda-chuva, carteirinha, senha 7, crachá, carrinho de bebê, remarcadora |
| 22 | `G28U RWKN` | Galeria Página 3 – térreo | canivete, batata, tereré, fantasia de baiana, bilhete do 43, guarda-chuva, carteirinha, senha 7, crachá, carrinho de bebê, remarcadora |
| 23 | `46DL E8V3` | Rua da galeria (Ciudad del Este) | canivete, batata, nota fiscal, tereré, fantasia de baiana, bilhete do 43, guarda-chuva, carteirinha, senha 7, crachá, carrinho de bebê, remarcadora |
| 24 | `SBF9 5K6L` | Elevador da galeria | canivete, batata, nota fiscal, fantasia de baiana, bilhete do 43, guarda-chuva, carteirinha, senha 7, crachá, carrinho de bebê, remarcadora |
| 25 | `DG4N UYF0` | Elevador da galeria | canivete, batata, fantasia de baiana, bilhete do 43, guarda-chuva, carteirinha, senha 7, crachá, carrinho de bebê, remarcadora |
| 26 | `MLRU ZAHA` | Arquivo morto (Ato III) | canivete, fantasia de baiana, bilhete do 43, guarda-chuva, carteirinha, senha 7, crachá, carimbo, carrinho de bebê, remarcadora |
| 27 | `SSHH NL2P` | Salão dos guichês (Ato III) | canivete, fantasia de baiana, bilhete do 43, guarda-chuva, carteirinha, senha 7, crachá, carimbo, processo 1972/43, carrinho de bebê, remarcadora |
| 28 | `DT7X C0U8` | Salão dos guichês (Ato III) | canivete, fantasia de baiana, bilhete do 43, guarda-chuva, carteirinha, senha 7, crachá, carimbo, processo 1972/43, carrinho de bebê, remarcadora |
| 29 | `0YVK 3DMM` | Sala do Dr. Lechuga (Ato III) | canivete, fantasia de baiana, bilhete do 43, guarda-chuva, carteirinha, senha 7, crachá, carimbo, processo 1972/43, carrinho de bebê, remarcadora |

Senha secreta / secret password: `TRUB 0R00` (modo Trubo-R: o Bira anda mais rápido).
