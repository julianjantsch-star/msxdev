# SUDOKU para MSX2 (SCREEN 8) — cartucho ROM em assembly Z80

`SUDOKU.ROM` é um cartucho de 16 KB (em 4000h) para MSX2 ou superior, todo em assembly Z80.
Usa a SCREEN 8 (256×212, 256 cores) e os comandos de hardware do VDP V9938 (HMMV/LMMM).
Menu e textos em **Português** ou **English** (escolha na última linha do menu, ou com ←/→).

## Como jogar no WebMSX

Abra <https://webmsx.org/?MACHINE=MSX2A&MOUSE_MODE=1> e arraste o `SUDOKU.ROM` para a tela.
Também dá para passar por URL: `?MACHINE=MSX2A&MOUSE_MODE=1&ROM=<url do SUDOKU.ROM>`.
(`MOUSE_MODE=1` liga o mouse na porta 1.)

| Tecla | Ação |
| --- | --- |
| Setas | mover o cursor |
| 1–9 | colocar número (ou nota, no modo lápis) |
| P ou Espaço | liga/desliga o **lápis** (notas) |
| 0 / BS / DEL | apagar |
| U | desfazer |
| H | dica (3 por partida) |
| M ou ESC | pausa (o cronômetro para) |

**Mouse na porta 1** (junto com o teclado):
- O clique esquerdo numa casa seleciona a casa.
- O clique esquerdo nos números 1–9 do painel joga aquele número; na caixa do LÁPIS liga e desliga o lápis; nas lâmpadas pede uma dica.
- O botão direito liga e desliga o lápis.
- No menu, clicar num nível começa a partida; nas caixas de pausa e de fim de jogo, o clique continua o jogo.

## Recursos

- **6 níveis**, como no sudoku.com: Fácil, Médio, Difícil, Expert, Mestre e Extremo.
  Os puzzles foram classificados por um resolvedor lógico (`tools/gen_puzzles.py`):
  - Fácil e Médio saem só com *singles*.
  - Difícil pede candidatos travados ou pares.
  - Expert pede X-Wing, XY-Wing ou trincas.
  - Mestre e Extremo pedem técnicas avançadas.

  Cada puzzle tem solução única. A cada partida o jogo embaralha dígitos, linhas, colunas,
  faixas e transposição, o que dá milhões de variações de cada um.
- **Lápis**: até 9 notas por célula. Quando você acerta um número, ele sai sozinho das notas
  da linha, da coluna e do quadrado.
- **Destaques**: linha, coluna e quadrado do cursor, e as outras células com o mesmo número.
  A casa selecionada tem moldura laranja grossa, que fica verde no modo lápis.
- **Erros em vermelho** e **3 vidas** (corações). Sem vidas, você pode continuar com +1 vida
  ou começar um jogo novo.
- **Animação** em onda quando completa uma linha, uma coluna ou um quadrado, com som.
- **Cronômetro** (funciona em 50 e 60 Hz) e recorde por nível, que vale enquanto a máquina
  estiver ligada.
- **Final**: parabéns, tempo, nível, erros e aviso de novo recorde.

## Compilar

```sh
python3 tools/gen_puzzles.py 8 > tools/puzzles.txt   # opcional: gera um novo banco (~40 s)
python3 tools/gen_data.py                            # gera src/data.asm
cd src && pasmo --bin sudoku.asm ../SUDOKU.ROM
```
